<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Wales')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;700;900&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

        
        <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>" />

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

        <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body dir="rtl" class="overflow-hidden">

        <div x-data="{ sidebarOpen: false }" class="relative flex h-screen overflow-hidden text-gray-800 bg-white font-roboto">
            <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="flex flex-col flex-1 overflow-hidden bg-gray-100">
                <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <main class="flex-1 overflow-y-auto">
                    <div class="px-4 py-8 sm:px-6" :class="sidebarOpen ? 'container mx-auto' : ''">
                        <div>
                            <h1 class="text-2xl font-medium text-gray-700 sm:text-3xl"><?php echo $__env->yieldPushContent('title'); ?></h1>

                            <div class="hidden mt-3 overflow-y-auto text-sm lg:items-center lg:flex whitespace-nowrap">
                                <a href="<?php echo e(route('dashboard')); ?>" class="text-indigo-600 dark:text-gray-200 hover:underline">
                                    لوحة التحكم
                                </a>

                                <span class="mx-1 text-gray-500 dark:text-gray-300">
                                    /
                                </span>

                                <?php echo $__env->yieldPushContent('breadcrumb'); ?>
                            </div>
                        </div>

                        <div class="mt-6">
                            <?php echo $__env->yieldContent('body'); ?>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <!-- Scripts -->
        <?php echo $__env->make('includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
 
</html>



<?php /**PATH /home/creaspo/Desktop/wales/resources/views/layouts/app.blade.php ENDPATH**/ ?>