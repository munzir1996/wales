<header class="bg-white border-b border-gray-100">
    <div class="flex items-center justify-between px-4 py-4 sm:px-6">
        <div class="flex items-center space-x-4">
            <button @click="sidebarOpen = !sidebarOpen" class="text-gray-500 focus:outline-none">
                <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 6H20M4 12H20M4 18H11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </button>

            
        </div>

        <div class="flex items-center space-x-2 sm:space-x-4">
            

            <div x-data="{ dropdownOpen: false }" class="relative inline-block">
                <button @click="dropdownOpen = ! dropdownOpen" class="relative z-10 flex items-center flex-shrink-0 text-sm text-gray-600 focus:outline-none">
                    <?php echo e(Auth::user()->name); ?>

                </button>

                <div class="absolute left-0 z-20 w-56 py-2 mt-2 overflow-hidden bg-white rounded-md shadow-xl"
                    x-show="dropdownOpen"
                    x-cloak
                    x-transition:enter="transition ease-out duration-100 transform"
                    x-transition:enter-start="opacity-0 scale-95"
                    x-transition:enter-end="opacity-100 scale-100"
                    x-transition:leave="transition ease-in duration-75 transform"
                    x-transition:leave-start="opacity-100 scale-100"
                    x-transition:leave-end="opacity-0 scale-95"
                    @click.away="dropdownOpen = false"
                >
                    <a href="#" class="flex items-center p-3 -mt-2 text-sm text-gray-600 transition-colors duration-200 transform dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-white">
                        <div class="mx-1">
                            <h1 class="text-sm font-semibold text-gray-700 dark:text-gray-200"> إسم المستخدم</h1>
                            <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(Auth::user()->name); ?></p>
                        </div>
                    </a>

                    <hr class="border-gray-200 dark:border-gray-700 ">

         

                    <a href="<?php echo e(route('logout')); ?>" class="block px-4 py-2 text-sm text-gray-600 capitalize transition-colors duration-200 transform dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-white"
                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        تسجيل خروج
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH /home/creaspo/Desktop/wales/resources/views/includes/header.blade.php ENDPATH**/ ?>