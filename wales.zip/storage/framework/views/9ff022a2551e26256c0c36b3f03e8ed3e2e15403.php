<?php $__env->startPush('title'); ?>
  Athrib
<?php $__env->stopPush(); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
    <section class="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-2">
        <div class="flex items-center justify-between px-6 py-3 bg-white shadow-sm rounded-xl">
            <div>
                <p class="font-medium text-gray-500">عدد المستخدمين </p>

                <div class="flex items-end space-x-2">
                    <h2 class="mt-1 text-2xl font-medium text-gray-800"><?php echo e($userCount); ?></h2>
                    <span class="text-indigo-500">

                    </span>
                </div>
            </div>

            <div class="p-2 text-white bg-indigo-500 rounded-lg">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
            </div>
        </div>

        <div class="flex items-center justify-between px-6 py-3 bg-white shadow-sm rounded-xl ">
            <div>
                <p class="font-medium text-gray-500">عدد الأبار</p>

                <div class="flex items-end space-x-2">
                    <h2 class="mt-1 text-2xl font-medium text-gray-800"><?php echo e($wellCount); ?></h2>
                    <span class="text-indigo-500">

                    </span>
                </div>
            </div>

            <div class="p-2 text-white bg-indigo-500 rounded-lg">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                </svg>
            </div>
        </div>
    </section>

    <section class="mt-6 space-y-6 xl:flex xl:space-y-0">
        <div class="w-full p-4 bg-white rounded-lg shadow-sm xl:p-6"> 
            <h2 class="text-lg font-medium text-gray-700 capitalize sm:text-xl md:text-2xl">اخر المشاريع </h2>

            <p class="flex items-center mt-2 space-x-2 text-gray-500">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-green-500" viewBox="0 0 20 20"
                    fill="currentColor">
                    <path fill-rule="evenodd"
                        d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                        clip-rule="evenodd" />
                </svg>

                <span>التي تمت </span>
            </p>

            <div class="flex flex-col mt8">
                <div class="overflow-x-auto">
                    <div class="inline-block min-w-full align-middle">
                        <div class="overflow-hidden">
                            <table class="min-w-full divide-y divide-gray-200" id="wells-table">
                                <thead>
                                    <tr>

                                        <th scope="col"
                                            class="px-6 py-3 text-sm font-medium tracking-wider text-right text-gray-500 uppercase">
                                            <span> The owner</span>
                                        </th>
                                        <th scope="col"
                                            class="px-6 py-3 text-sm font-medium tracking-wider text-right text-gray-500 uppercase">
                                            <span> the consulting board</span>
                                        </th>
                                        <th scope="col"
                                            class="px-6 py-3 text-sm font-medium tracking-wider text-right text-gray-500 uppercase">
                                            <span> the financier</span>
                                        </th>
                                        <th scope="col"
                                            class="px-6 py-3 text-sm font-medium tracking-wider text-right text-gray-500 uppercase">
                                            <span> project manager </span>
                                        </th>
                                        <th scope="col"
                                            class="px-6 py-3 text-sm font-medium tracking-wider text-right text-gray-500 uppercase">
                                            <span> Execution date</span>
                                        </th>
                                        <th scope="col"
                                            class="px-6 py-3 text-sm font-medium tracking-wider text-right text-gray-700 uppercase whitespace-nowrap">
                                        </th>

                                    </tr>
                                </thead>

                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php $__currentLoopData = $basicInformations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basicInformation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-6 py-4 font-medium text-gray-800 whitespace-nowrap">
                                                <?php echo e($basicInformation->owner); ?>

                                            </td>
                                            <td class="px-6 py-4 font-medium whitespace-nowrap">
                                                <?php echo e($basicInformation->advisor); ?>

                                            </td>
                                            <td class="px-6 py-4 font-medium text-gray-700 whitespace-nowrap">
                                                <?php echo e($basicInformation->funded); ?>

                                            </td>
                                            <td class="px-6 py-4 text-gray-700 capitalize whitespace-nowrap">
                                                <?php echo e($basicInformation->project_manager); ?>

                                            </td>
                                            <td class="px-6 py-4 text-gray-700 capitalize whitespace-nowrap">
                                                <?php echo e($basicInformation->start_date); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="flex items-center space-x-4">
                                                    <a href="<?php echo e(route('basic-informations.show', $basicInformation->id)); ?>" class="text-gray-500 focus:outline-none hover:text-indigo-500">
                                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                                        </svg>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('vendor/js/datatables.min.js')); ?>"></script>


<script>
    //Datatable
    $(document).ready(function () {
        $('#wells-table').DataTable({
            dom: 'Bfrtip',
            "language": {
                "emptyTable": "لا توجد بيانات متوفرة في الجدول",
                "search": "بحث:",
                "lengthMenu": "_MENU_ السجلات",
                "sInfo": "إظهار الصفحة _PAGE_ من _PAGES_",
                "sInfoEmpty": "إظهار 0 إلى 0 من 0 السجلات",
                "zeroRecords": "لم يتم العثور على سجلات مطابقة",
                "infoFiltered": "(تمت تصفيته من إجمالي السجلات _MAX_)",
            },
            buttons: [
                'excel', 'pdf'
            ],

        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/creaspo/Desktop/wales/resources/views/dashboard.blade.php ENDPATH**/ ?>