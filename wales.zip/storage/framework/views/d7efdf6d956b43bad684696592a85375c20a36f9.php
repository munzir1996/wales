<link rel="stylesheet" href="<?php echo e(asset('vendor/css/toastr-rtl.min.css')); ?>">
<style>
    [x-cloak] { display: none !important; }
</style>
<?php echo $__env->yieldPushContent('css'); ?>
<?php /**PATH /home/creaspo/Desktop/wales/resources/views/includes/head.blade.php ENDPATH**/ ?>