<script src="<?php echo e(asset('vendor/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/toastr.min.js')); ?>"></script>
<?php echo $__env->yieldPushContent('js'); ?>
<?php /**PATH /home/creaspo/Desktop/wales/resources/views/includes/scripts.blade.php ENDPATH**/ ?>