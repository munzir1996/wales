<link rel="stylesheet" href="{{ asset('vendor/css/toastr-rtl.min.css') }}">
<style>
    [x-cloak] { display: none !important; }
</style>
@stack('css')
