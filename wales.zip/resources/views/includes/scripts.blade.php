<script src="{{ asset('vendor/js/jquery.min.js') }}"></script>
<script src="{{ asset('vendor/js/toastr.min.js') }}"></script>
@stack('js')
